package com.example.flutter_proyecto_tienda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
